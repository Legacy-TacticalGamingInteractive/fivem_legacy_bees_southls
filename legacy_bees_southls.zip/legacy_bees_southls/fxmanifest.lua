fx_version 'cerulean'
game {'gta5'}

this_is_a_map 'yes'

data_file 'DLC_ITYP_REQUEST' 'bzzz_props_beehive_pack.ytyp'

author 'LegacysMaps and Bzzz For Bee Props'
description 'Bee Colony South LS'
version '1.0'
